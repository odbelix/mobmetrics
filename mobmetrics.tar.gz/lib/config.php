<?
function __autoload($aClassName) {
        include($aClassName.".php");
}
include_once('dblib.php');
?>
