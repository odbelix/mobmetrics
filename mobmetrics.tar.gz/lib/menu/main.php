<ul class="nav">
	<li class="active"><a href="index.php"><?=home?></a></li>
    <li><a href="device.php?view=d"><?=devices?></a></li>
    <li><a href="device.php?view=p"><?=plans?></a></li>
    <li><a href="device.php?view=r"><?=reports?></a></li>
    <!-- <li><a href="device.php?view=p"><?=config?></a></li> -->
</ul>